<?php
	function component($name, $address, $age, $language_spoken, $is_married){
		$element = "
		<div class=\"border\">
			<form action=\"search.php\" method=\"post\">
			<h5 class=\"title\">$name</h5>
			<h6><span class=\"\">$address</span></h6>
			<h6><span class=\"\">$age</span></h6>
			<h6><span class=\"\">$language_spoken</span></h6>
			<h6><span class=\"\">$is_married</span></h6>
			</form>
		</div>
		";
		echo $element;
	}
?>