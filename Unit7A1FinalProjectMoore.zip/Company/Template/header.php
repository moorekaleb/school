
<head>
	<title>Company Employees</title>

	<style>
  <?php include "MyStyles.css" ?>
	</style>
	
	<h1>Company Employees</h1>
	<nav> 
	<div>
		<ul>
			<li><a href='../index.php'>Add Employee</a></li>
			<li><a href='search.php'>Search Employees</a></li>
		</ul>
	</div>
 </nav>
</head>
<body>