<?php
	//include needed files
	require_once('../Admin/db_connect.php');
	require_once('component.php');
	require_once('../Admin/ReadDB.php');
	
	$database = new ReadDB();

?>

<!DOCTYPE html>
<html>

<?php include('header.php'); ?>
<div class="center">
	<!-- search through names form -->
	<form action="search.php" method="POST">
		<label>Search by Name:<label>
		<input type="text" name="sname"><br/>
		<button type="submit" name="namesearch">Search</button>
		<button type="submit" name="ndelete">Delete</button>
	</form><br/>
	
	<!-- search through languages form -->
	<form action="search.php" method="POST">
		<label>Search by Language:<label>
		<input type="text" name="slanguage"><br/>
		<button type="submit" name="languagesearch">Search</button>
		<button type="submit" name="ldelete">Delete</button>
	</form><br/><br/>
	
	
	
</div>

	<div class="container" >
		<?php
			//get database query information
			if(isset($_POST['namesearch'])){
				$name = filter_var($_POST['sname'], FILTER_SANITIZE_STRING);
				$result = $database->getNameData($name);
			}elseif(isset($_POST['languagesearch'])){
				$language = filter_var($_POST['slanguage'], FILTER_SANITIZE_STRING);
				$result = $database->getLanguageData($language);
			}
		else{
			$result = $database->getNameData();
		}//delete database information
		if(isset($_POST['ndelete'])){
			$name = filter_var($_POST['sname'], FILTER_SANITIZE_STRING);
			$database->removeNameData($name);
			$result = $database->getNameData();
			
			}
			if(isset($_POST['ldelete'])){
				$language = filter_var($_POST['slanguage'], FILTER_SANITIZE_STRING);
				$database->removeLanguageData($language);
				$result = $database->getNameData();
			}
			if($result == null){
			echo "<br/>No Results found!";
			}else{//display database results
				while($row = mysqli_fetch_assoc($result)){
					component($row['employee_name'], $row['employee_address'], $row['age'], $row['language_spoken'], $row['is_married']);
				}
			}
		
		?>
	</div>
<?php include('footer.php'); ?>
</html>