<?php
//Create search query
include('../Admin/db_connect.php');
	include('component.php');
	$query ="SELECT * FROM employee_data ORDER BY employee_name desc";
	$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html>
<?php include('header.php');?>
<!-- create cvs file from seperate file. -->
	<form method ="post" action="../Admin/export.php">
		<button type="submit" name="export" value="CSV Export">Export</button>
	</form>
		
<div class="container">
<?php
	//display query information
	while($row = mysqli_fetch_assoc($result)){
		component($row['employee_name'], $row['employee_address'], $row['age'], $row['language_spoken'], $row['is_married']);
	}
?>
</div>
<?php include('footer.php');?>
</html>