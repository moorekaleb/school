	<footer>
	<p>Welcome to the Team!</p>
	</footer>
</body>