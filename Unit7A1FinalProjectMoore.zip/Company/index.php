<?php
	//connect to database
	include('Admin/db_connect.php');
	$errors = [];
	//is the submit butten pressed
	if(isset($_POST['submit'])){
		//check to see if all values have been included
		if(empty($_POST['name'])){
			$errors['name'] = 'A name is required. <br/>';
		}
		else{
			$name = mysqli_real_escape_string($conn, $_POST['name']);
		}
		if(empty($_POST['address'])){
			$errors['address'] = 'An address is required. <br/>';
		}
		else{
			$address = mysqli_real_escape_string($conn, $_POST['address']);
		}
		if(empty($_POST['age'])){
			$errors['age'] = 'An age is required. <br/>';
		}
			
		if(!isset($_POST['language'])){
			$errors['language'] = 'A language is required. <br/>';
		}
		else{	
			$language = mysqli_real_escape_string($conn, $_POST['language']);
		}
		if(!isset($_POST['marriage'])){
			$errors['marriage'] = 'A marriage status is required. <br/>';
		}
		else{
			$marriage = mysqli_real_escape_string($conn, $_POST['marriage']);
		}
		//is the value a numeric number for age
		if(is_numeric($_POST['age'])){
			//is the age 16 or more
			if($_POST['age'] >= 16){
				$age = mysqli_real_escape_string($conn, $_POST['age']);
			}
			else{
				$errors['young'] = 'Please enter an age that is 16 or older.';
			}
		}
		else{
			$errors['number'] = 'Please enter a valid age.';
		}//Display any errors that occured
	if(array_filter($errors)){
		foreach($errors as $error){
			echo "$error <br>";
		}
	}
	else{
	//create sql
	$sql = "INSERT INTO employee_data(employee_name,employee_address,age,language_spoken,is_married) VALUES ('$name', '$address', '$age', '$language', '$marriage')";
	
	//save to db and check
	if(mysqli_query($conn, $sql)){
		//success
		header('index.php');
	}else{
		//error
		echo 'query error: '.mysqli_error($conn);
	}
	}
	}
	

?>


<!DOCTYPE html>
<html>
<?php include('Template/header.php'); ?>
	<!-- Form to create new employee record-->
	<div class="center">
	<form action="index.php" method="POST">
		<label>Your First and Last Name:</label>
		<input type="text" name="name"><br/>
		<label>Your Address:</label>
		<input type="text" name="address"><br/>
		<label>Your Age:</label>
		<input type="text" name="age"><br/>
		<label for="language">Your Primary Language:</label><br/>
		<select id="listbox" name="language" size="3">
			<option value="English">English</option>
			<option value="French">French</option>
			<option value="Spanish">Spanish</option>
		</select><br/>
		<label>Married Or Single?:</label><br/>
		<label for="married">Married</label>
		<input type="radio" id="married" name="marriage" value="MARRIED"><br/>
		<label for="single">Single</label>
		<input type="radio" id="single" name="marriage" value="SINGLE"><br/>
		<button type="submit" name="submit">Add Employee</button>
		</form>
	</div>



<?php include('Template/footer.php'); ?>
</html>




