 <?php  
 include('db_connect.php');
      //export.php  
 if(isset($_POST["export"]))  
 {  
 
      header('Content-Type: text/csv; charset=utf-8');  
      header('Content-Disposition: attachment; filename=data.txt');  
      $output = fopen("php://output", "w");  
      fputcsv($output, array('Name', 'Address', 'Age', 'Language', 'Marriage'));  
      $query = "SELECT * from employee_data ORDER BY employee_name DESC";  
      $result = mysqli_query($conn, $query);  
      while($row = mysqli_fetch_assoc($result))  
      {  
           fputcsv($output, $row);  
      }  
      fclose($output);  
 }  
 ?>  