<?php

	//connect to database
	$conn = mysqli_connect('localhost','root','','company_db');
	
	//check connection 
	if(!$conn){
		echo 'Connection error: '.mysqli_connect_error();
	}
?>