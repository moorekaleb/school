<?php

Class ReadDb
{	
	private $recordname;
	//get product from database
	public function getNameData($recordname = ""){
		$this->recordname=$recordname;
		//connect to database
		$this->conn = mysqli_connect('localhost','root','','company_db');
		//check connection
		if(!$this->conn){
			die("Connection Failed: ".mysqli_connect_error());
		}
		$sql = "SELECT * FROM employee_data WHERE employee_name LIKE '%$recordname%'"; 
		
		$result = mysqli_query($this->conn, $sql);

		if(mysqli_num_rows($result)>0){
			return $result;
		}
	}
	
		//get product from database
	public function getLanguageData($recordname = ""){

		$this->recordname=$recordname;
		//connect to database
		$this->conn = mysqli_connect('localhost','root','','company_db');
		//check connection
		if(!$this->conn){
			die("Connection Failed: ".mysqli_connect_error());
		}
			//create search query
			$sql = "SELECT * FROM employee_data WHERE language_spoken = '$recordname'"; 
			$result = mysqli_query($this->conn, $sql);
		if(mysqli_num_rows($result)>0){
			//return query results
			return $result;
		}
	}
		//remove database record based on language
		public function removeLanguageData($recordname = ""){
		
		$this->recordname=$recordname;
		//connect to database
		$this->conn = mysqli_connect('localhost','root','','company_db');
		//check connection
		if(!$this->conn){
			die("Connection Failed: ".mysqli_connect_error());
		}
			//deletion query
			$sql = "DELETE FROM employee_data WHERE language_spoken = '$recordname'"; 
			//delete record
			mysqli_query($this->conn, $sql);

	}
	
		public function removeNameData($recordname = ""){
		$this->recordname=$recordname;
		//connect to database
		$this->conn = mysqli_connect('localhost','root','','company_db');
		//check connection
		if(!$this->conn){
			die("Connection Failed: ".mysqli_connect_error());
		}
		//delete query
		$sql = "DELETE FROM employee_data WHERE employee_name LIKE '%$recordname%'"; 
		//delete record 
		mysqli_query($this->conn, $sql);
		//check for deletion successfully 
		if(mysqli_query($this->conn, $sql)){
			echo "Records were deleted successfully.";
		} else{
			echo "ERROR: Could not able to execute $sql " . mysqli_error($conn);
}

	}
}