-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Feb 28, 2022 at 07:44 AM
-- Server version: 5.7.36
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `company_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `employee_data`
--

DROP TABLE IF EXISTS `employee_data`;
CREATE TABLE IF NOT EXISTS `employee_data` (
  `employee_name` varchar(30) NOT NULL,
  `employee_address` varchar(150) NOT NULL,
  `age` int(3) NOT NULL,
  `language_spoken` varchar(30) NOT NULL,
  `is_married` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee_data`
--

INSERT INTO `employee_data` (`employee_name`, `employee_address`, `age`, `language_spoken`, `is_married`) VALUES
('Jodi Herra', '4485 Johns St Columbus OH', 22, 'Spanish', 'MARRIED'),
('Taylor Vogelsong', '222 Deerborn Dr Clevland OH', 16, 'French', 'MARRIED'),
('Carl Winston', '3320 Coolmen Dr Carlin MI', 50, 'French', 'SINGLE'),
('Laura Demuth', '6657 Country Rd 22 Cinncinati OH', 33, 'English', 'SINGLE'),
('Captain Sparkles', '5546 Kissme Rd Columbus OH', 21, 'French', 'MARRIED'),
('Lucifer Morningstar', '666 Hellslane Brimstone AL', 16, 'Spanish', 'MARRIED'),
('Kaleb Moore', '1099 towh min', 22, 'English', 'MARRIED'),
('Kaleb Michael Moore', '10299 township road', 22, 'Spanish', 'SINGLE'),
('Kaleb Moore', '1099 towh min', 22, 'English', 'MARRIED'),
('Tay Hidoria', '33330 Cooler St Dooland IN', 16, 'English', 'SINGLE'),
('Kaleb Michael Moore', '10299 township road', 50, 'French', 'MARRIED'),
('Jodi Herra', '4485 Johns St Columbus OH', 21, 'English', 'SINGLE');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
