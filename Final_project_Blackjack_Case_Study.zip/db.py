#!/usr/bin/env python3
import sqlite3
from contextlib import closing
import objects
#connection status
conn = None
DB_FILE = "blackjack.sqlite"
FILENAME = "money.txt"

#connect to database
def connect():
    global conn
    if not conn:

        conn = sqlite3.connect(DB_FILE)
        conn.row_factory = sqlite3.Row

#close connection
def close():
    if conn:
        conn.close()

def makeSession(row):
    return objects.Session(row["sessionID"], row["stopMoney"], row["stopMoney"])

class Database():
    
    #View all database records
    def viewAll(self):
        with closing(conn.cursor()) as c:
            query = '''SELECT * FROM Session WHERE sessionID =
                                        (SELECT MAX(sessionID) FROM Session)'''
            c.execute(query)
            results = c.fetchone()
            if results:
                session = makeSession(results)
                session.ID += 1
            else:
                session = objects.Session()
        return session

    #read database money
    def read_session_money(self):
        try:
            with closing(conn.cursor()) as c:
                query = '''SELECT stopMoney FROM Session WHERE stopTime = (
                                    SELECT MAX(stopTime) FROM Session)'''
                c.execute(query)
                money = c.fetchall()
            return money
        except FileNotFoundError:
            return "Database not Found"

    #read database session ID
    def read_session_ID(self):
        with closing(conn.cursor()) as c:
            query = '''SELECT sessionID FROM Session WHERE sessionID =
                                    (SELECT MAX(sessionID) FROM Session)'''
            c.execute(query)
            ID = c.fetchall()
        return ID

    #write data to database
    def write_session(self, values):
        with closing(conn.cursor()) as c:
            query = '''INSERT INTO Session (sessionID, startTime, startMoney, addedMoney,
                            stopTime, stopMoney)
                            VALUES (?, ?, ?, ?, ?, ?)'''
            c.execute(query, (values[0], values[1], values[2], values[3], values[4], values[5]))
            conn.commit()

def read_money():
        try:
            with open(FILENAME) as file:
                for line in file:
                    line = line.replace("\n", "")
                    return line
        except FileNotFoundError:
            return 0.0


#write data to file
def write_money(money):
        with open(FILENAME, "w") as file:
            file.write(str(money))

