#!/usr/bin/env python3
import random
from datetime import datetime

#session class for database
class Session:
    def __init__(self, ID=1,  startMoney=100, stopMoney=100,
                  addedMoney=0, stopTime="", startTime=datetime.now()):
        self.__ID = ID
        self.__startTime = startTime
        self.__startMoney = startMoney
        self.__addedMoney = addedMoney
        self.__stopTime = stopTime
        self.__stopMoney = stopMoney

    @property
    def ID(self):
        return self.__ID
    @property
    def startTime(self):
        return self.__startTime
    @property
    def startMoney(self):
        return self.__startMoney
    @property
    def addedMoney(self):
        return self.__addedMoney
    @property
    def stopTime(self):
        return self.__stopTime
    @property
    def stopMoney(self):
        return self.__stopMoney

    @ID.setter
    def ID(self, ID):
        self.__ID = ID
    @startTime.setter
    def startTime(self, startTime):
        self.__startTime = startTime
    @startMoney.setter
    def startMoney(self, startMoney):
        self.__startMoney = startMoney
    @addedMoney.setter
    def addedMoney(self, addedMoney):
        self.__addedMoney = addedMoney
    @stopTime.setter
    def stopTime(self, stopTime):
        self.__stopTime = stopTime
    @stopMoney.setter
    def stopMoney(self, stopMoney):
        self.__stopMoney = stopMoney

#card class
class Card:
    #constructor
    def __init__(self, rank, suit):
        self.__rank = rank
        self.__suit = suit

    #get string of card
    def cardName(self):
        return "%s of %s"%(self.__rank["rank"], self.__suit)

    @property
    def card(self):
        return self.__rank
    
#Deck class
class Deck:
    #constructor
    def __init__(self, suits = ["Clubs", "Diamonds", "Hearts", "Spades"]):
        self.__suits = suits
        self.__ranks = [
                {"rank": "Ace", "value": 11},
                {"rank": "2", "value": 2},
                {"rank": "3", "value": 3},
                {"rank": "4", "value": 4},
                {"rank": "5", "value": 5},
                {"rank": "6", "value": 6},
                {"rank": "7", "value": 7},
                {"rank": "8", "value": 8},
                {"rank": "9", "value": 9},
                {"rank": "10", "value": 10},
                {"rank": "Jack", "value": 10},
                {"rank": "Queen", "value": 10},
                {"rank": "King", "value": 10},
            ]
        self.__deck = []
        self.createDeck()

    #Create deck with cards
    def createDeck(self):
        for suit in self.__suits:
            for rank in self.__ranks:
                self.__deck.append(Card(rank, suit))

    #shuffle deck
    def shuffle(self):
        random.shuffle(self.__deck)

    #deal cards
    def dealCards(self, amount):
        self.__hand = []
        for i in range(amount):
            if len(self.__deck) > 0:
                card = self.__deck.pop()
                self.__hand.append(card)
        return self.__hand

#class player
class Hand:
    #constructor
    def __init__(self, deck, points = 0):
        self.__points = points
        self.__deck = deck
        self.__hand = []
        cards = self.__deck.dealCards(2)
        for card in cards:
            self.__hand.append(card)
            self.pointCount()
        
    def hit(self):
        cards = self.__deck.dealCards(1)
        for card in cards:
            self.__hand.append(card)
            self.pointCount()

    def pointCount(self):
        card = len(self.__hand) - 1
        rank = self.__hand[card].card
        if rank["rank"] == "Ace":
            tem = self.__points + rank["value"]
            if tem > 21:
                self.__points += 2
            else:
                self.__points = tem
        else:
            self.__points += rank["value"]

    @property
    def handSize(self):
        return len(self.__hand)
    
    @property
    def hand(self):
        return self.__hand

    @property
    def points(self):
        return self.__points
    
