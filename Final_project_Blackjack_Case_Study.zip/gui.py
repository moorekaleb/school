#!/usr/bin/env python3
import tkinter as tk
from tkinter import ttk
import objects as ob
import db
import locale as lc
from datetime import datetime

#GUI CLASS
class BlackjackFrame(ttk.Frame):
    def __init__(self, parent):
        ttk.Frame.__init__(self, parent, padding="10 10 10 10")
        self.parent = parent
        self.file = db.Database()
        result = lc.setlocale(lc.LC_ALL, "")
        if result == "C":
            lc.setlocal(lc.LC_ALL, "en_US")
        self.session = self.file.viewAll()
        self.deck = ob.Deck()
        self.deck.shuffle()
        self.dealer = ob.Hand(self.deck, 0)
        self.player = ob.Hand(self.deck)
        #define string variables for entry field
        self.money = tk.StringVar()
        self.bet = tk.StringVar()
        self.dcards = tk.StringVar()
        self.dpoints = tk.StringVar()
        self.ycards = tk.StringVar()
        self.ypoints = tk.StringVar()
        self.results = tk.StringVar()
        self.initComponents()

    def initComponents(self):
        
        #show components
        self.pack()

        #labels and textboxes
        ttk.Label(self, text="Money:").grid(column=0, row=0, sticky=tk.E)
        ttk.Label(self, text="Bet:").grid(column=0, row=1, sticky=tk.E)
        ttk.Label(self, text="DEALER").grid(column=0, row=2, sticky=tk.E)
        ttk.Label(self, text="Cards:").grid(column=0, row=3, sticky=tk.E)
        ttk.Label(self, text="Points:").grid(column=0, row=4, sticky=tk.E)
        ttk.Label(self, text="YOU").grid(column=0, row=5, sticky=tk.E)
        ttk.Label(self, text="Cards:").grid(column=0, row=6, sticky=tk.E)
        ttk.Label(self, text="Points:").grid(column=0, row=7, sticky=tk.E)
        ttk.Label(self, text="RESULT:").grid(column=0, row=9, sticky=tk.E)
        ttk.Entry(self, width=25, textvariable=self.money, state="readonly").grid(column=1,
                                                                                  row=0, columnspan=2)
        ttk.Entry(self, width=25, textvariable=self.bet).grid(column=1, row=1, columnspan=2)
        ttk.Entry(self, width=25, textvariable=self.dcards, state="readonly").grid(column=1,
                                                                                   row=3, columnspan=4)
        ttk.Entry(self, width=25, textvariable=self.dpoints, state="readonly").grid(column=1,
                                                                                    row=4, columnspan=2)
        ttk.Entry(self, width=25, textvariable=self.ycards, state="readonly").grid(column=1,
                                                                                   row=6, columnspan=4)
        ttk.Entry(self, width=25, textvariable=self.ypoints, state="readonly").grid(column=1,
                                                                                    row=7, columnspan=2)
        ttk.Entry(self, width=25, textvariable=self.results, state="readonly").grid(column=1,
                                                                                   row=9, columnspan=4)
        self.money.set(lc.currency(self.session.startMoney))
        
        self.makeButtons()
        #add padding to all child components
        for child in self.winfo_children():
            child.grid_configure(padx=5, pady=3)
    #make buttons
    def makeButtons(self):

        ttk.Button(self, text="Hit", command=self.hit).grid(column=1, row=8, padx=5)
        ttk.Button(self, text="Stand", command=self.stand).grid(column=2, row=8, padx=5)
        ttk.Button(self, text="Play", command=self.play).grid(column=1, row=10, padx=5)
        ttk.Button(self, text="Exit", command=self.exit).grid(column=2, row=10)

    def play(self):
        
        bet = self.bet.get()
        if not bet.replace(".", "", 1).isdigit():
            self.results.set("A bet is Required")
        elif float(bet) < 5:
            self.results.set("The minimum bet is $5")
        elif float(bet) > 1000:
            self.results.set("The maximum bet is $1,000")
        elif float(bet) > self.session.stopMoney:
            self.results.set("You don't have enough money")
        else:
            self.deck = ob.Deck()
            self.deck.shuffle()
            self.dealer = ob.Hand(self.deck, 0)
            self.player = ob.Hand(self.deck)
            self.results.set("")
            result = lc.setlocale(lc.LC_ALL, "")
            if result == "C":
                lc.setlocal(lc.LC_ALL, "en_US")
                
            self.money.set(lc.currency(self.session.stopMoney))
            try:
                hand = self.dealer.hand
                self.dcards.set(hand[0].card["rank"])
                self.ycards.set(showHand(self.player))
                self.ypoints.set(self.player.points)
                self.dpoints.set(hand[0].card["value"])
                self.results.set("Hit or Stand")
            except ValueError:
                self.results.set("Please enter a valid input.")

    def exit(self):
        addedMoney = self.session.stopMoney - self.session.startMoney
        if addedMoney < 0:
            self.session.addedMoney = 0
        else:
            self.session.addedMoney = addedMoney
        values = [self.session.ID, self.session.startTime, self.session.startMoney,
                  self.session.stopMoney - self.session.startMoney,
                  datetime.now(), self.session.stopMoney]
        self.file.write_session(values)
        self.parent.destroy()

    def hit(self):
        bet = self.bet.get()
        if not bet.replace(".", "", 1).isdigit():
            self.results.set("A bet is Required")
        elif float(bet) < 5:
            self.results.set("The minimum bet is $5")
        elif float(bet) > 1000:
            self.results.set("The maximum bet is $1,000")
        elif float(bet) > self.session.stopMoney:
            self.results.set("You don't have enough money")
        else:
            self.results.set("")
            self.player.hit()
            cards = showHand(self.player)
            self.ycards.set(cards)
            self.ypoints.set(self.player.points)
            self.results.set("Hit again or Stand")
            

    def stand(self):
        bet = self.bet.get()
        if not bet.replace(".", "", 1).isdigit():
            self.results.set("A bet is Required")
        elif float(bet) < 5:
            self.results.set("The minimum bet is $5")
        elif float(bet) > 1000:
            self.results.set("The maximum bet is $1,000")
        elif float(bet) > self.session.stopMoney:
            self.results.set("You don't have enough money")
        else:
            bet = float(bet)
            self.results.set("")
            self.results.set(winningHand(self.player, self.dealer, bet, self.session))
            self.dcards.set(showHand(self.dealer))
            self.dpoints.set(self.dealer.points)
            self.money.set(lc.currency(self.session.stopMoney))
            

def showHand(player):
    hand = player.hand
    cards = []
    for card in hand:
        cards.append(card.card["rank"])
    return cards

#winning hand
def winningHand(player, dealer, bet, session):
    result = lc.setlocale(lc.LC_ALL, "")
    if result == "C":
        lc.setlocal(lc.LC_ALL, "en_US")
    pl_points = player.points
    de_points = dealer.points
    while de_points < 17:
        dealer.hit()
        de_points = dealer.points
    if pl_points > 21:
        session.stopMoney -= round(bet, 2)
        return "Oops! You busted. You lose!"
    elif de_points > 21:
        session.stopMoney += round(bet * 1.5, 2)
        return "Yay! The dealer busted. You win!"
    elif pl_points > de_points:
        session.stopMoney += round(bet * 1.5, 2)
        return "Yay! You were closer to 21 than the dealer. You win!"
    else:
        session.stopMoney -= round(bet, 2)
        return "Oops! The dealer beat you. You lose!"

if __name__ == "__main__":
    db.connect()
    root = tk.Tk()
    root.title("BLACKJACK")
    BlackjackFrame(root)
    root.mainloop()
    db.close()
