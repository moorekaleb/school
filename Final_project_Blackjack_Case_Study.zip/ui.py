#!/usr/bin/env python3
import locale as lc
import objects, db
from datetime import datetime, timedelta, time

#start of interface tier
def showHand(player):
    hand = player.hand
    for card in hand:
        print(card.cardName())
    print()

#betting function
def Bet(money):
    if money < 5:
        choice = input("Would you like to buy more chips? (y/n): ")
        if choice.lower() == "y":
            chips = round(float(input("How much would you like: ")), 2)
            money += chips
            db.write_money(money)
        else:
            return False
    while True:
        bet = float(input("Bet: "))
        if bet > money:
            print("You do not have enough money for this bet")
        elif bet < 5:
            print("The minimum bet is $5")
        elif bet > 1000:
            print("The maximum bet is $1,000")
        else:
            return bet
        
#dealers starting hand
def dealerHand(dealer):
    hand = dealer.hand
    print(hand[0].cardName())
    print()

#winning hand
def winningHand(player, dealer, bet):
    result = lc.setlocale(lc.LC_ALL, "")
    if result == "C":
        lc.setlocal(lc.LC_ALL, "en_US")
    pl_points = player.points
    de_points = dealer.points
    money = round(float(db.read_money()), 2)
    while de_points < 17:
        dealer.hit()
        de_points = dealer.points
    print("DEALER'S CARDS:")
    showHand(dealer)
    print("YOUR POINTS: \t", pl_points)
    print("DEALER'S POINTS: ", de_points)
    print()
    if pl_points > 21:
        print("Oops! You busted. You lose!")
        money -= bet
        db.write_money(money)
        print("Money: ", lc.currency(money))
    elif de_points > 21:
        print("Yay! The dealer busted. You win!")
        money += bet * 1.5
        db.write_money(money)
        print("Money: ", lc.currency(money))
    elif pl_points > de_points:
        print("Yay! You were closer to 21 than the dealer. You win!")
        money += bet * 1.5
        db.write_money(money)
        print("Money: ", lc.currency(money))
    else:
        print("Oops! The dealer beat you. You lose!")
        money -= bet
        db.write_money(money)
        print("Money: ", lc.currency(money))
    print()

#time function
def calcTime(current_time):
    time_format = "%I:%M:%S %p"
    new_time = datetime.now()
    elapse_time = new_time - current_time
    minutes = elapse_time.seconds // 60
    seconds = elapse_time.seconds % 60
    hours = minutes // 60
    minutes = minutes % 60

    elapse_time = time(hours, minutes, seconds)

    print("Stop time: ", new_time.strftime(time_format))
    print("Elapsed time: ", elapse_time)


#Play the game
def Play():
    con = "y"
    result = lc.setlocale(lc.LC_ALL, "")
    if result == "C":
        lc.setlocal(lc.LC_ALL, "en_US")

    while con.lower() == "y":
        deck = objects.Deck()
        deck.shuffle()
        dealer = objects.Hand(deck, 0)
        player = objects.Hand(deck)
        try:
            money = round(float(db.read_money()), 2)
            print("Money: ", lc.currency(money))
            bet = Bet(money)
            if bet == False:
                break
            print()
            print("DEALER'S SHOW CARD:")
            dealerHand(dealer)
            while True:
                print("YOUR CARDS")
                showHand(player)
                choice = input("Hit or stand? (hit/stand): ")
                print()
                if choice.lower() == "hit":
                    player.hit()
                elif choice.lower() == "stand":
                    break
                else:
                    print("Please choose a valid answer.")
            winningHand(player, dealer, bet)
        except ValueError:
            print("Please enter a valid input.")
        con = input("Play again? (y/n): ")
        print()

        
#game function
def StartGame():
    time_format = "%I:%M:%S %p"
    current_time = datetime.now()
    print("Start time: ", current_time.strftime(time_format))
    print()
    Play()
    calcTime(current_time)
    print("Come back soon!")
