#!/usr/bin/env python3
import ui, objects, db


def main():
    print("BLACKJACK!")
    print("Blackjack payout is 3:2")
    ui.StartGame()

if __name__ == "__main__":
    main()
